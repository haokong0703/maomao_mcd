/* ============================================================================
 * mcd-mcp.js  ·  猫猫点餐 · mcd-mcp 适配层
 * ============================================================================
 * 本文件定义与 mcd-mcp（麦当劳 MCP 服务）对接的「统一接口 McdMcp」，并给出两种
 * 实现：
 *
 *   1) MockMcdMcpClient   —— 内存假数据实现，严格对齐真实 mcd-mcp 字段契约，
 *                            无需联网即可把"菜单→加购→计价→下单→查单→取消"
 *                            全流程跑通（默认使用，方便演示与本地开发）。
 *
 *   2) AgentMcdMcpClient  —— 文档化桥接实现。浏览器页面无法直接调用 MCP 服务，
 *                            真实下单/查单由 WorkBuddy 代理侧执行 mcd-mcp 工具。
 *                            本类逐方法标注了对应的真实工具名与请求体示例，
 *                            业务层（app.js）在切换真实环境时只需替换实例。
 *
 * 业务侧只依赖 McdMcp 接口，切换真实环境只需一行：
 *   const mcd = new MockMcdMcpClient();      // 本地演示（默认）
 *   const mcd = new AgentMcdMcpClient();     // 接入真实 mcd-mcp（代理侧执行）
 *
 * 所有方法均返回 Promise，失败时抛出 McdError，便于上层统一 try/catch。
 * ========================================================================== */
(function (global) {
  'use strict';

  /* --------------------------------------------------------------------------
   * 统一业务错误类型
   * ------------------------------------------------------------------------ */
  class McdError extends Error {
    constructor(message, code) {
      super(message);
      this.name = 'McdError';
      this.code = code || 'MCD_ERROR';
    }
  }

  /* ==========================================================================
   * 1. 内存假数据实现（MockMcdMcpClient）
   *    字段命名与真实 mcd-mcp 保持一致，便于无缝切换到 AgentMcdMcpClient。
   * ======================================================================== */
  class MockMcdMcpClient {
    constructor() {
      this.storeCode = 'SH0001';          // 示例门店编码
      this.addressId = 'ADDR0001';        // 示例外送地址 ID
      this.failNextCreate = false;        // 测试开关：下一次下单故意失败
      this._orders = {};                  // orderId -> order 快照
      this._seq = 1;
      this._menu = this._buildMenu();
      // 演示用状态推进时间窗（毫秒）：支付后多久进入各阶段
      this.T_PREPARING = 0;               // 支付后立即制作中
      this.T_READY = 20 * 1000;           // 20s 后出餐待取
      this.T_DONE = 45 * 1000;            // 45s 后完成
    }

    /* ---- 假菜单（猫猫化命名，productCode 为示例值，真实值来自 query-meals） ---- */
    _buildMenu() {
      return [
        {
          category: '喵堡堡 · 汉堡',
          items: [
            { productCode: 'BIGMAC',  name: '巨喵霸',       desc: '双层牛肉 + 喵喵酱，猫猫界顶流', price: 24.0, img: '🍔',
              mods: [ { group: '酸黄瓜', code: 'PG', options: [ { label: '正常', key: 'PG_N', selected: true }, { label: '去酸黄瓜', key: 'PG_OFF', selected: false } ] } ] },
            { productCode: 'MLCHK',   name: '喵辣鸡腿堡',   desc: '香辣鸡腿，尾尖都馋',         price: 21.0, img: '🍔',
              mods: [ { group: '辣度', code: 'SP', options: [ { label: '标准辣', key: 'SP_N', selected: true }, { label: '微辣', key: 'SP_LOW', selected: false } ] } ] },
            { productCode: 'CHZ',     name: '芝喵堡',       desc: '双层芝士，软乎乎',           price: 13.0, img: '🧀' },
            { productCode: 'GRIL',    name: '板烧喵腿堡',   desc: '嫩烤鸡腿，不辣也香',         price: 22.0, img: '🍗' },
            { productCode: 'DBLCHZ',  name: '双层芝喵堡',   desc: '双倍芝士攻击',               price: 17.0, img: '🧀' }
          ]
        },
        {
          category: '喵薯与小食',
          items: [
            { productCode: 'FRIES_L', name: '喵薯条（大）', desc: '金黄酥脆，蘸喵酱',   price: 12.0, img: '🍟' },
            { productCode: 'FRIES_M', name: '喵薯条（中）', desc: '刚刚好的分量',       price: 10.0, img: '🍟' },
            { productCode: 'WINGS',   name: '麦辣喵翅',     desc: '两对翅膀，飞起来',   price: 18.0, img: '🍗' },
            { productCode: 'CORN',    name: '玉米喵杯',     desc: '清甜玉米粒',         price: 9.0,  img: '🌽' },
            { productCode: 'NUG6',    name: '喵喵鸡块（6块）', desc: '蘸酱更快乐',      price: 14.0, img: '🍗' }
          ]
        },
        {
          category: '喵甜心 · 甜品',
          items: [
            { productCode: 'MCFLUR',  name: '喵旋风（奥利奥）', desc: '冰淇淋 + 饼干碎', price: 15.0, img: '🍦' },
            { productCode: 'CONE',    name: '圆喵筒',           desc: '脆皮甜筒',       price: 5.0,  img: '🍦' },
            { productCode: 'PIE',     name: '喵苹果派',         desc: '热乎酥皮',       price: 7.0,  img: '🥧' }
          ]
        },
        {
          category: '喵饮品',
          items: [
            { productCode: 'COKE_M', name: '可喵乐（中）', desc: '快乐水',   price: 9.0, img: '🥤',
              mods: [ { group: '冰量', code: 'ICE', options: [ { label: '正常冰', key: 'ICE_N', selected: true }, { label: '少冰', key: 'ICE_L', selected: false }, { label: '去冰', key: 'ICE_OFF', selected: false } ] },
                      { group: '糖度', code: 'SUG', options: [ { label: '标准糖', key: 'SUG_N', selected: true }, { label: '少糖', key: 'SUG_L', selected: false } ] } ] },
            { productCode: 'SPRITE', name: '雪喵碧',       desc: '清爽气泡', price: 9.0, img: '🥤',
              mods: [ { group: '冰量', code: 'ICE', options: [ { label: '正常冰', key: 'ICE_N', selected: true }, { label: '去冰', key: 'ICE_OFF', selected: false } ] } ] },
            { productCode: 'OJ',     name: '喵橙汁',       desc: '鲜榨感',   price: 11.0, img: '🧃' },
            { productCode: 'COFFEE', name: '香喵咖啡',     desc: '提神醒喵', price: 13.0, img: '☕' },
            { productCode: 'SOY',    name: '喵豆浆',       desc: '温热无糖', price: 8.0,  img: '🥛' }
          ]
        },
        {
          category: '喵乐园餐 · 儿童',
          items: [
            { productCode: 'HAPPY',  name: '开心喵乐园餐', desc: '主餐+小食+玩具，猫仔专属', price: 32.0, img: '🎁',
              mods: [ { group: '主餐', code: 'MAIN', options: [ { label: '喵辣鸡腿堡', key: 'MAIN_CHK', selected: true }, { label: '芝喵堡', key: 'MAIN_CHZ', selected: false } ] },
                      { group: '玩具', code: 'TOY', options: [ { label: '猫咪玩偶', key: 'TOY_CAT', selected: true }, { label: '小鱼公仔', key: 'TOY_FISH', selected: false } ] } ] }
          ]
        }
      ];
    }

    _findItem(productCode) {
      for (const cat of this._menu) {
        const it = cat.items.find((x) => x.productCode === productCode);
        if (it) return it;
      }
      return null;
    }

    _delay(ms) { return new Promise((r) => setTimeout(r, ms || 350)); }

    /* ---- query-meals：菜单浏览 ---- */
    async queryMeals(params) {
      await this._delay();
      // 真实 mcd-mcp 需 storeCode + orderType(1/2)；此处返回全量菜单
      const orderType = params && params.orderType;
      return {
        storeCode: this.storeCode,
        orderType: orderType || 1,
        categories: this._menu.map((c) => ({
          category: c.category,
          items: c.items.map((i) => ({
            productCode: i.productCode, name: i.name, desc: i.desc,
            price: i.price, img: i.img,
            hasMods: !!(i.mods && i.mods.length)
          }))
        }))
      };
    }

    /* ---- query-meal-detail：菜品详情（含特制选项） ---- */
    async queryMealDetail(params) {
      await this._delay();
      const item = this._findItem(params && params.productCode);
      if (!item) throw new McdError('找不到这道喵喵餐品', 'NOT_FOUND');
      return {
        productCode: item.productCode, name: item.name, desc: item.desc,
        price: item.price, img: item.img,
        modifications: (item.mods || []).map((m) => ({
          group: m.group, code: m.code,
          options: m.options.map((o) => ({ label: o.label, key: o.key, selected: o.selected }))
        }))
      };
    }

    /* ---- calculate-price：计价（返回 takeWayList，到店自取需选 takeWayCode） ---- */
    async calculatePrice(params) {
      await this._delay();
      const items = (params && params.items) || [];
      if (!items.length) throw new McdError('购物车是空的，先挑点喵粮吧', 'EMPTY_CART');
      let subtotal = 0;
      for (const it of items) {
        const menuItem = this._findItem(it.productCode);
        if (!menuItem) throw new McdError('含有未知餐品：' + it.productCode, 'BAD_ITEM');
        subtotal += menuItem.price * (it.quantity || 1);
      }
      // 简单促销：满 60 减 10
      const discount = subtotal >= 60 ? 10 : 0;
      const total = Math.max(0, subtotal - discount);
      const orderType = params && params.orderType;
      // 到店(orderType=1)需 takeWayList；外送(orderType=2)无需
      const takeWayList = orderType === 2
        ? []
        : [ { code: '01', name: '堂食' }, { code: '02', name: '到店自取' } ];
      return { subtotal, discount, total, takeWayList };
    }

    /* ---- create-order：下单（核心） ---- */
    async createOrder(params) {
      await this._delay(500);
      if (!params) throw new McdError('订单参数缺失', 'BAD_PARAM');
      const { storeCode, orderType, beType, items } = params;
      if (!storeCode) throw new McdError('未选择门店', 'NO_STORE');
      if (!orderType || (orderType !== 1 && orderType !== 2)) throw new McdError('订单类型错误', 'BAD_ORDERTYPE');
      if (!beType) throw new McdError('未选择取餐方式', 'NO_BETYPE');
      if (!items || !items.length) throw new McdError('购物车是空的', 'EMPTY_CART');
      if (orderType === 1 && !params.takeWayCode) throw new McdError('到店场景需选择取餐方式(takeWayCode)', 'NO_TAKEWAY');
      if (orderType === 2 && !params.addressId) throw new McdError('外送场景需选择配送地址(addressId)', 'NO_ADDRESS');

      if (this.failNextCreate) {
        this.failNextCreate = false;
        throw new McdError('网络开了小差，下单失败，请重试 🐾', 'NETWORK');
      }

      const orderId = 'MCD' + (Date.now()) + (this._seq++);
      const snapshot = items.map((it) => {
        const m = this._findItem(it.productCode);
        return {
          productCode: it.productCode,
          name: m ? m.name : it.productCode,
          quantity: it.quantity,
          unitPrice: m ? m.price : 0,
          modifications: (it.modification && it.modification.values) ? it.modification.values : []
        };
      });
      const order = {
        orderId,
        storeCode,
        orderType,
        beType,
        takeWayCode: params.takeWayCode || null,
        addressId: params.addressId || null,
        remark: params.remark || '',
        items: snapshot,
        status: 'PENDING_PAYMENT',   // 待支付
        createdAt: Date.now(),
        paidAt: null,
        total: 0,
        payUrl: 'https://mock.mcd/pay/' + orderId
      };
      this._orders[orderId] = order;
      return {
        orderId,
        status: order.status,
        payUrl: order.payUrl,
        message: '下单成功，请完成支付 🐱'
      };
    }

    /* ---- 演示用：模拟支付完成（真实流程由用户在麦当劳 APP/扫码支付） ---- */
    async mockPay(orderId) {
      const o = this._orders[orderId];
      if (!o) throw new McdError('订单不存在', 'NOT_FOUND');
      if (o.status !== 'PENDING_PAYMENT') return { orderId, status: o.status };
      o.status = 'PAID';
      o.paidAt = Date.now();
      // 用计价结果回填 total
      const price = await this.calculatePrice({ orderType: o.orderType, items: o.items.map((i) => ({ productCode: i.productCode, quantity: i.quantity })) });
      o.total = price.total;
      return { orderId, status: o.status, total: o.total };
    }

    /* ---- query-order：订单状态查询（按时间推进状态机） ---- */
    async queryOrder(params) {
      await this._delay();
      const orderId = params && params.orderId;
      const o = this._orders[orderId];
      if (!o) throw new McdError('订单不存在或已过期', 'NOT_FOUND');
      this._advanceStatus(o);
      return JSON.parse(JSON.stringify(o));
    }

    _advanceStatus(o) {
      if (o.status === 'CANCELLED' || o.status === 'COMPLETED') return;
      if (o.status === 'PENDING_PAYMENT') return; // 等支付
      const t = Date.now() - (o.paidAt || o.createdAt);
      if (o.status === 'PAID') {
        // 已支付：到出餐时间前保持 PAID，不回退
        if (t >= this.T_READY) o.status = 'READY';
        return;
      }
      // PREPARING / READY：按时间推进到 READY / COMPLETED
      if (t >= this.T_DONE) o.status = 'COMPLETED';
      else if (t >= this.T_READY) o.status = 'READY';
      else o.status = 'PREPARING';
    }

    /* ---- cancel-order：取消订单 ---- */
    async cancelOrder(params) {
      await this._delay();
      const orderId = params && params.orderId;
      const reason = params && params.cancelReasonCode;
      const o = this._orders[orderId];
      if (!o) throw new McdError('订单不存在', 'NOT_FOUND');
      if (![1, 2, 3, 4, 5, -1].includes(Number(reason))) throw new McdError('取消原因码无效', 'BAD_REASON');
      if (o.status === 'READY' || o.status === 'COMPLETED') throw new McdError('订单已出餐/已完成，无法取消', 'NOT_CANCELABLE');
      if (o.status === 'CANCELLED') throw new McdError('订单已取消', 'ALREADY_CANCELLED');
      o.status = 'CANCELLED';
      o.cancelReasonCode = reason;
      return { orderId, status: 'CANCELLED', message: '订单已取消' };
    }

    /* ---- order-list：历史订单 ---- */
    async orderList() {
      await this._delay();
      return Object.values(this._orders)
        .sort((a, b) => b.createdAt - a.createdAt)
        .map((o) => JSON.parse(JSON.stringify(o)));
    }

    /* ---- query-nearby-stores：附近门店（取 storeCode / beCode） ---- */
    async queryNearbyStores() {
      await this._delay();
      return [
        { storeCode: 'SH0001', name: '喵街旗舰店',   address: '上海市喵喵区爪印路 1 号', beCode: 'DT01' },
        { storeCode: 'SH0002', name: '鱼干路便利店', address: '上海市喵喵区鱼干路 88 号', beCode: 'DT02' },
        { storeCode: 'SH0003', name: '猫窝社区店',   address: '上海市喵喵区猫窝里 5 号',  beCode: 'DT03' }
      ];
    }
  }

  /* ==========================================================================
   * 2. 真实桥接实现（AgentMcdMcpClient）
   *    浏览器无法直接调用 MCP；下列每个方法都对应一个真实 mcd-mcp 工具。
   *    在 WorkBuddy 代理侧，应把对应方法体替换为对该 MCP 工具的调用。
   *    此处保留「方法签名 + 真实工具名 + 请求体示例 + 说明」，作为对接契约。
   * ======================================================================== */
  class AgentMcdMcpClient {
    /* 代理侧执行 mcd-mcp 工具的占位函数。
     * 真实接入时，由 WorkBuddy 在对话中调用对应 MCP 工具并回传结果。 */
    async _call(toolName, payload) {
      // 示例（伪代码，实际由代理侧执行）：
      //   const res = await mcp__mcd-mcp__<toolName>(payload);
      //   return res;
      throw new McdError(
        '该方法需在 WorkBuddy 代理侧执行 mcd-mcp 工具：' + toolName +
        '。请在代理环境将本方法体替换为真实 MCP 调用。',
        'NEED_AGENT'
      );
    }

    // 对应 mcp__mcd-mcp__query-meals
    // 入参示例：{ storeCode: 'SH0001', orderType: 1 }
    queryMeals(params) { return this._call('query-meals', params); }

    // 对应 mcp__mcd-mcp__query-meal-detail
    // 入参示例：{ productCode: 'BIGMAC', storeCode: 'SH0001', orderType: 1 }
    queryMealDetail(params) { return this._call('query-meal-detail', params); }

    // 对应 mcp__mcd-mcp__calculate-price
    // 入参示例：{ storeCode:'SH0001', orderType:1, beType:1, items:[{productCode:'BIGMAC',quantity:1}] }
    calculatePrice(params) { return this._call('calculate-price', params); }

    // 对应 mcp__mcd-mcp__create-order
    // 入参示例：
    // {
    //   storeCode:'SH0001', orderType:1, beType:1,
    //   takeWayCode:'02',
    //   items:[{ productCode:'BIGMAC', quantity:1,
    //            modification:{ values:[{code:'PG',key:'PG_OFF',quantity:1}] } }]
    // }
    // 注：beType 1=到店自取(不传 beCode) 2=麦乐送(必传 beCode+addressId)
    //     5=得来速(必传 beCode) 6=团餐(必传 beCode+addressId)
    createOrder(params) { return this._call('create-order', params); }

    // 对应 mcp__mcd-mcp__query-order
    // 入参示例：{ orderId: 'MCDxxxx' }
    queryOrder(params) { return this._call('query-order', params); }

    // 对应 mcp__mcd-mcp__cancel-order
    // 入参示例：{ orderId:'MCDxxxx', cancelReasonCode:'3' }
    // cancelReasonCode: 1=改主意了 2=重复下单 3=点错了 4=地址填错 5=送达时间错 -1=其它
    cancelOrder(params) { return this._call('cancel-order', params); }

    // 对应 mcp__mcd-mcp__order-list（仅麦当劳订单，不含商城）
    orderList() { return this._call('order-list', {}); }

    // 对应 mcp__mcd-mcp__query-nearby-stores
    // 入参示例：{ latitude: 31.23, longitude: 121.47 }
    queryNearbyStores(params) { return this._call('query-nearby-stores', params); }
  }

  /* ---- 导出到全局，供 app.js 使用（非模块，兼容 file:// 直接打开） ---- */
  global.McdMcp = {
    McdError,
    MockMcdMcpClient,
    AgentMcdMcpClient
  };
})(typeof window !== 'undefined' ? window : this);
