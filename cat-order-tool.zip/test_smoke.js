/* 冒烟测试：验证 MockMcdMcpClient 全流程字段契约与错误分支。
 * 可由 `npm test` 运行，也可直接 `node test_smoke.js`。 */
const { McdMcp } = require('./mcd-mcp.js');
const { MockMcdMcpClient, McdError } = McdMcp;

(async () => {
  const mcd = new MockMcdMcpClient();
  const assert = (c, m) => { if (!c) throw new Error('断言失败: ' + m); };

  // 1) 门店
  const stores = await mcd.queryNearbyStores();
  assert(stores.length === 3 && stores[0].storeCode, '门店列表异常');
  console.log('✓ 门店:', stores.map(s => s.storeCode).join(','));

  // 2) 菜单
  const meals = await mcd.queryMeals({ storeCode: mcd.storeCode, orderType: 1 });
  assert(meals.categories.length === 5, '菜单分类异常');
  const bigmac = meals.categories[0].items.find(i => i.productCode === 'BIGMAC');
  assert(bigmac && bigmac.hasMods, '巨喵霸应有特制');
  console.log('✓ 菜单分类数:', meals.categories.length, '| 巨喵霸价:', bigmac.price);

  // 3) 详情
  const detail = await mcd.queryMealDetail({ productCode: 'BIGMAC', storeCode: mcd.storeCode, orderType: 1 });
  assert(detail.modifications.length === 1, '详情特制组异常');
  console.log('✓ 详情特制组:', detail.modifications[0].group);

  // 4) 计价（到店）
  const items = [
    { productCode: 'BIGMAC', quantity: 2, modification: { values: [{ code: 'PG', key: 'PG_OFF', quantity: 1 }] } },
    { productCode: 'FRIES_L', quantity: 1 }
  ];
  const price = await mcd.calculatePrice({ storeCode: mcd.storeCode, orderType: 1, beType: 1, items });
  assert(price.takeWayList.length === 2, '到店应返回 takeWayList');
  assert(price.total === 24*2 + 12 - (24*2+12>=60?10:0), '到店总价异常: ' + price.total);
  console.log('✓ 计价:', JSON.stringify(price));

  // 5) 下单（到店自取）
  const order = await mcd.createOrder({
    storeCode: mcd.storeCode, orderType: 1, beType: 1, takeWayCode: '02', items
  });
  assert(order.orderId && order.payUrl && order.status === 'PENDING_PAYMENT', '下单返回异常');
  console.log('✓ 下单:', order.orderId, order.status);

  // 6) 支付 + 状态推进
  const paid = await mcd.mockPay(order.orderId);
  assert(paid.status === 'PAID', '支付后应 PAID');
  let st = await mcd.queryOrder({ orderId: order.orderId });
  assert(st.status === 'PAID', '查单应 PAID');
  console.log('✓ 支付后状态:', st.status, '| 应付:', st.total);

  // 7) 取消（制作中前可取消）
  const cancel = await mcd.cancelOrder({ orderId: order.orderId, cancelReasonCode: '3' });
  assert(cancel.status === 'CANCELLED', '取消应 CANCELLED');
  console.log('✓ 取消:', cancel.status);

  // 8) 错误分支：空购物车计价
  let threw = false;
  try { await mcd.calculatePrice({ storeCode: mcd.storeCode, orderType: 1, beType: 1, items: [] }); }
  catch (e) { threw = (e instanceof McdError) && e.code === 'EMPTY_CART'; }
  assert(threw, '空购物车应抛 EMPTY_CART');
  console.log('✓ 错误分支 EMPTY_CART 生效');

  // 9) 外送下单需 addressId
  threw = false;
  try {
    await mcd.createOrder({ storeCode: mcd.storeCode, orderType: 2, beType: 2, items, takeWayCode: '02' });
  } catch (e) { threw = e.code === 'NO_ADDRESS'; }
  assert(threw, '外送缺 addressId 应抛 NO_ADDRESS');
  console.log('✓ 外送缺地址错误分支生效');

  console.log('\n🎉 全部冒烟测试通过');
})().catch(e => { console.error('❌ 测试失败:', e.message); process.exit(1); });
