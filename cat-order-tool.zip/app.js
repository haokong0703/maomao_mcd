/* ============================================================================
 * app.js · 喵喵点餐 交互逻辑 + 订单状态管理
 * 业务层只依赖 window.McdMcp（MockMcdMcpClient / AgentMcdMcpClient 任一实现）。
 * 全流程：菜单浏览 → 菜品详情(特制) → 加购 → 购物车 → 结算计价 → 下单 → 查单/取消
 * 所有 mcd-mcp 调用均包裹 try/catch，统一 Toast 报错 + 加载态。
 * ========================================================================== */
(function () {
  'use strict';

  // ---- 默认使用 Mock 实现；接入真实 mcd-mcp 时改为 new McdMcp.AgentMcdMcpClient() ----
  const mcd = new McdMcp.MockMcdMcpClient();

  // ---- 全局状态 ----
  const state = {
    stores: [],
    selectedStore: null,
    categories: [],
    activeCat: 0,
    cart: [],            // { productCode, name, price, img, qty, mods:[{group,code,key,label}] }
    orders: [],
    checkout: null       // { mode:'pickup'|'delivery', takeWayCode, remark, price }
  };

  // ---- DOM 快捷获取 ----
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };

  /* ====================== 通用工具：Toast / 加载态 ====================== */
  let toastTimer = null;
  function toast(msg, type) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast' + (type ? ' ' + type : '');
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 2600);
  }

  function setLoading(btn, loading, text) {
    if (!btn) return;
    if (loading) {
      btn.dataset.old = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span>' + (text || '处理中…');
    } else {
      btn.disabled = false;
      btn.innerHTML = btn.dataset.old || text || '';
    }
  }

  async function safe(fn, failMsg) {
    try {
      return await fn();
    } catch (e) {
      const msg = (e && e.message) ? e.message : (failMsg || '出错了');
      toast('🐾 ' + msg, 'error');
      console.error(e);
      return null;
    }
  }

  /* ====================== 初始化 ====================== */
  async function init() {
    const stores = await safe(() => mcd.queryNearbyStores(), '门店加载失败');
    if (stores && stores.length) {
      state.stores = stores;
      state.selectedStore = stores[0];
      renderStoreSelect();
      await loadMenu();
    }
    switchTab('menu');
  }

  function renderStoreSelect() {
    const sel = $('storeSelect');
    sel.innerHTML = '';
    state.stores.forEach((s) => {
      const o = el('option');
      o.value = s.storeCode;
      o.textContent = s.name + '（' + s.storeCode + '）';
      sel.appendChild(o);
    });
    sel.onchange = () => {
      state.selectedStore = state.stores.find((s) => s.storeCode === sel.value);
      loadMenu();
    };
  }

  /* ====================== 菜单浏览 ====================== */
  async function loadMenu() {
    if (!state.selectedStore) return;
    const data = await safe(
      () => mcd.queryMeals({ storeCode: state.selectedStore.storeCode, orderType: 1 }),
      '菜单加载失败'
    );
    if (!data) return;
    state.categories = data.categories || [];
    state.activeCat = 0;
    renderCatTabs();
    renderMenu();
  }

  function renderCatTabs() {
    const wrap = $('catTabs');
    wrap.innerHTML = '';
    state.categories.forEach((c, i) => {
      const b = el('button', 'cat-tab' + (i === state.activeCat ? ' active' : ''), c.category);
      b.onclick = () => { state.activeCat = i; renderCatTabs(); renderMenu(); };
      wrap.appendChild(b);
    });
  }

  function renderMenu() {
    const grid = $('menuGrid');
    grid.innerHTML = '';
    const cat = state.categories[state.activeCat];
    if (!cat) return;
    cat.items.forEach((it) => {
      const card = el('div', 'dish');
      card.innerHTML =
        '<button class="add" title="加入购物车">＋</button>' +
        '<div class="emoji">' + (it.img || '🍽️') + '</div>' +
        '<h3>' + it.name + '</h3>' +
        '<div class="desc">' + (it.desc || '') + '</div>' +
        (it.hasMods ? '<div class="tag-mod">可定制特制 ✎</div>' : '') +
        '<div class="price">¥' + Number(it.price).toFixed(2) + '</div>';
      card.onclick = () => openDetail(it.productCode);
      card.querySelector('.add').onclick = (e) => { e.stopPropagation(); openDetail(it.productCode); };
      grid.appendChild(card);
    });
  }

  /* ====================== 菜品详情（含特制选项） ====================== */
  async function openDetail(productCode) {
    const d = await safe(() => mcd.queryMealDetail({ productCode, storeCode: state.selectedStore.storeCode, orderType: 1 }), '详情加载失败');
    if (!d) return;
    const chosen = {}; // group -> {code,key,label}
    (d.modifications || []).forEach((m) => {
      const def = m.options.find((o) => o.selected) || m.options[0];
      if (def) chosen[m.group] = { code: m.code, key: def.key, label: def.label };
    });

    const body = $('detailBody');
    body.innerHTML = '';
    body.appendChild(el('div', 'big-emoji', d.img || '🍽️'));
    body.appendChild(el('h2', null, d.name));
    body.appendChild(el('div', 'm-desc', d.desc || ''));

    (d.modifications || []).forEach((m) => {
      const g = el('div', 'mod-group');
      g.appendChild(el('div', 'mg-title', '🔧 ' + m.group));
      m.options.forEach((o) => {
        const chip = el('span', 'mod-opt' + (chosen[m.group] && chosen[m.group].key === o.key ? ' active' : ''), o.label);
        chip.onclick = () => {
          chosen[m.group] = { code: m.code, key: o.key, label: o.label };
          g.querySelectorAll('.mod-opt').forEach((c) => c.classList.remove('active'));
          chip.classList.add('active');
        };
        g.appendChild(chip);
      });
      body.appendChild(g);
    });

    const qtyRow = el('div', 'stepper');
    const minus = el('button', 'minus', '－');
    const qtyLabel = el('span', 'qty', '1');
    const plus = el('button', null, '＋');
    let qty = 1;
    minus.onclick = () => { qty = Math.max(1, qty - 1); qtyLabel.textContent = qty; };
    plus.onclick = () => { qty = Math.min(20, qty + 1); qtyLabel.textContent = qty; };
    qtyRow.appendChild(minus); qtyRow.appendChild(qtyLabel); qtyRow.appendChild(plus);
    body.appendChild(qtyRow);

    body.appendChild(el('div', 'm-price', '¥' + (Number(d.price) * 1).toFixed(2)));

    const addBtn = el('button', 'btn btn-primary', '加入购物车 🐾');
    addBtn.style.width = '100%';
    addBtn.onclick = () => {
      addToCart({
        productCode: d.productCode,
        name: d.name,
        price: Number(d.price),
        img: d.img,
        qty: qty,
        mods: Object.keys(chosen).map((g) => ({ group: g, code: chosen[g].code, key: chosen[g].key, label: chosen[g].label }))
      });
      closeModal('detailModal');
      toast('已加入购物车 🐱', 'success');
    };
    body.appendChild(addBtn);

    $('detailModal').hidden = false;
  }

  /* ====================== 购物车 ====================== */
  function modsSignature(item) {
    return item.productCode + '|' + item.mods.map((m) => m.key).sort().join(',');
  }

  function addToCart(item) {
    const sig = modsSignature(item);
    const exist = state.cart.find((c) => modsSignature(c) === sig);
    if (exist) exist.qty += item.qty;
    else state.cart.push({ ...item });
    renderCart();
  }

  function renderCart() {
    const list = $('cartList');
    list.innerHTML = '';
    let total = 0;
    state.cart.forEach((c, idx) => {
      const line = c.price * c.qty;
      total += line;
      const row = el('div', 'cart-item');
      row.innerHTML =
        '<div class="emoji">' + (c.img || '🍽️') + '</div>' +
        '<div class="info"><div class="name">' + c.name + '</div>' +
        (c.mods.length ? '<div class="mods">特制：' + c.mods.map((m) => m.label).join('、') + '</div>' : '') +
        '<div class="unit">¥' + c.price.toFixed(2) + ' / 份</div></div>';
      const stepper = el('div', 'stepper');
      const minus = el('button', 'minus', '－');
      const q = el('span', 'qty', String(c.qty));
      const plus = el('button', null, '＋');
      minus.onclick = () => { c.qty = Math.max(1, c.qty - 1); renderCart(); };
      plus.onclick = () => { c.qty = Math.min(20, c.qty + 1); renderCart(); };
      stepper.appendChild(minus); stepper.appendChild(q); stepper.appendChild(plus);
      row.appendChild(stepper);
      row.appendChild(el('div', 'line-price', '¥' + line.toFixed(2)));
      const del = el('button', 'del', '删除');
      del.onclick = () => { state.cart.splice(idx, 1); renderCart(); };
      row.appendChild(del);
      list.appendChild(row);
    });

    $('cartCount').textContent = state.cart.reduce((s, c) => s + c.qty, 0);
    $('cartTotal').textContent = '¥' + total.toFixed(2);
    const has = state.cart.length > 0;
    $('cartEmpty').style.display = has ? 'none' : 'block';
    $('cartFooter').hidden = !has;
  }

  function buildMcpItems() {
    return state.cart.map((c) => ({
      productCode: c.productCode,
      quantity: c.qty,
      modification: c.mods.length
        ? { values: c.mods.map((m) => ({ code: m.code, key: m.key, quantity: 1 })) }
        : undefined
    }));
  }

  /* ====================== 结算（计价 → 下单） ====================== */
  async function openCheckout() {
    if (!state.cart.length) { toast('购物车是空的 🐾', 'error'); return; }
    state.checkout = { mode: 'pickup', takeWayCode: null, remark: '', price: null, failSim: false };
    await renderCheckout();
    $('checkoutModal').hidden = false;
  }

  async function renderCheckout() {
    const ck = state.checkout;
    const body = $('checkoutBody');
    body.innerHTML = '';
    body.appendChild(el('h2', null, '🐾 确认订单'));

    // 取餐方式
    const modeBlock = el('div', 'checkout-block');
    modeBlock.appendChild(el('div', 'cb-title', '取餐方式'));
    const m1 = el('label', 'opt-card' + (ck.mode === 'pickup' ? ' active' : ''));
    m1.innerHTML = '🏠 到店自取（orderType=1 / beType=1）';
    const m2 = el('label', 'opt-card' + (ck.mode === 'delivery' ? ' active' : ''));
    m2.innerHTML = '🛵 麦乐送外送（orderType=2 / beType=2）';
    m1.onclick = () => { ck.mode = 'pickup'; ck.takeWayCode = null; renderCheckout(); };
    m2.onclick = () => { ck.mode = 'delivery'; renderCheckout(); };
    modeBlock.appendChild(m1); modeBlock.appendChild(m2);
    body.appendChild(modeBlock);

    // 计价（拿到 total 与 takeWayList）
    const orderType = ck.mode === 'pickup' ? 1 : 2;
    const beType = ck.mode === 'pickup' ? 1 : 2;
    const price = await safe(
      () => mcd.calculatePrice({ storeCode: state.selectedStore.storeCode, orderType, beType, items: buildMcpItems() }),
      '计价失败'
    );
    ck.price = price;

    // 到店：选择 takeWayCode
    if (ck.mode === 'pickup' && price && price.takeWayList && price.takeWayList.length) {
      const twBlock = el('div', 'checkout-block');
      twBlock.appendChild(el('div', 'cb-title', '自取方式'));
      if (!ck.takeWayCode && price.takeWayList[0]) ck.takeWayCode = price.takeWayList[0].code;
      price.takeWayList.forEach((tw) => {
        const c = el('label', 'opt-card' + (ck.takeWayCode === tw.code ? ' active' : ''));
        c.innerHTML = tw.name + '（' + tw.code + '）';
        c.onclick = () => { ck.takeWayCode = tw.code; renderCheckout(); };
        twBlock.appendChild(c);
      });
      body.appendChild(twBlock);
    }

    // 外送：备注
    if (ck.mode === 'delivery') {
      const rBlock = el('div', 'checkout-block');
      rBlock.appendChild(el('div', 'cb-title', '订单备注（选填，≤50字）'));
      const ta = el('input', 'field-input');
      ta.maxLength = 50;
      ta.placeholder = '如：无接触配送 / 放门口';
      ta.value = ck.remark;
      ta.oninput = () => { ck.remark = ta.value; };
      rBlock.appendChild(ta);
      body.appendChild(rBlock);
    }

    // 价格摘要
    if (price) {
      const sum = el('div', 'checkout-summary');
      sum.innerHTML =
        '<div class="row"><span>小计</span><span>¥' + price.subtotal.toFixed(2) + '</span></div>' +
        (price.discount ? '<div class="row"><span>优惠</span><span>-¥' + price.discount.toFixed(2) + '</span></div>' : '') +
        '<div class="row total"><span>应付</span><span>¥' + price.total.toFixed(2) + '</span></div>';
      body.appendChild(sum);
    }

    // 开发/测试开关：模拟下单失败（演示错误分支）
    const dev = el('div', 'dev-row');
    const cb = el('input');
    cb.type = 'checkbox'; cb.id = 'failSim';
    cb.checked = ck.failSim;
    cb.onchange = () => { ck.failSim = cb.checked; };
    const lab = el('label');
    lab.appendChild(cb);
    lab.appendChild(document.createTextNode(' 模拟「下单失败」以测试错误处理'));
    dev.appendChild(lab);
    body.appendChild(dev);

    // 提交
    const submit = el('button', 'btn btn-primary', '提交订单 🐱');
    submit.style.width = '100%';
    submit.style.marginTop = '8px';
    submit.onclick = () => submitOrder(submit);
    body.appendChild(submit);
  }

  async function submitOrder(btn) {
    const ck = state.checkout;
    if (!ck || !ck.price) { toast('请先完成结算信息', 'error'); return; }
    if (ck.mode === 'pickup' && !ck.takeWayCode) { toast('请选择自取方式', 'error'); return; }
    if (ck.mode === 'delivery' && ck.remark.length > 50) { toast('备注超过 50 字', 'error'); return; }

    if (ck.failSim) mcd.failNextCreate = true; // 触发 Mock 失败分支

    const payload = {
      storeCode: state.selectedStore.storeCode,
      orderType: ck.mode === 'pickup' ? 1 : 2,
      beType: ck.mode === 'pickup' ? 1 : 2,
      items: buildMcpItems(),
      remark: ck.mode === 'delivery' ? ck.remark : ''
    };
    if (ck.mode === 'pickup') payload.takeWayCode = ck.takeWayCode;
    else payload.addressId = mcd.addressId;

    setLoading(btn, true, '提交中…');
    const res = await safe(() => mcd.createOrder(payload), '下单失败');
    setLoading(btn, false, '提交订单 🐱');
    if (!res) return; // safe 已 Toast

    // 清空购物车 + 关闭弹窗 + 跳转订单
    state.cart = [];
    renderCart();
    closeModal('checkoutModal');
    toast('下单成功，请完成支付 🐱', 'success');
    await refreshOrders();
    switchTab('orders');
  }

  /* ====================== 订单列表 / 状态查询 / 取消 ====================== */
  async function refreshOrders() {
    const list = await safe(() => mcd.orderList(), '订单加载失败');
    if (!list) return;
    state.orders = list;
    renderOrders();
  }

  function statusText(s) {
    return ({
      PENDING_PAYMENT: '待支付', PAID: '已支付', PREPARING: '制作中',
      READY: '待取餐', COMPLETED: '已完成', CANCELLED: '已取消'
    })[s] || s;
  }
  function lineTotal(o) {
    if (o.total > 0) return o.total;
    return o.items.reduce((s, i) => s + (i.unitPrice * i.quantity), 0);
  }
  function canCancel(s) { return ['PENDING_PAYMENT', 'PAID', 'PREPARING'].includes(s); }

  function renderOrders() {
    const wrap = $('ordersList');
    wrap.innerHTML = '';
    if (!state.orders.length) { $('ordersEmpty').style.display = 'block'; return; }
    $('ordersEmpty').style.display = 'none';

    state.orders.forEach((o) => {
      const card = el('div', 'order-card');
      card.innerHTML =
        '<div class="o-head"><span class="o-id">订单号 ' + o.orderId + '</span>' +
        '<span class="o-status status-' + o.status + '">' + statusText(o.status) + '</span></div>' +
        '<div class="o-items">' + o.items.map((i) => i.name + '×' + i.quantity).join('，') + '</div>' +
        '<div class="o-foot"><span class="o-total">¥' + lineTotal(o).toFixed(2) + '</span></div>';

      const actions = el('div', 'order-actions');
      const refresh = el('button', 'btn btn-ghost btn-sm', '刷新状态');
      refresh.onclick = async () => {
        const updated = await safe(() => mcd.queryOrder({ orderId: o.orderId }), '查询失败');
        if (updated) { await refreshOrders(); }
      };
      actions.appendChild(refresh);

      if (o.status === 'PENDING_PAYMENT') {
        const pay = el('button', 'btn btn-primary btn-sm', '模拟支付完成');
        if (typeof mcd.mockPay !== 'function') pay.style.display = 'none'; // 真实环境走 payUrl
        pay.onclick = async () => {
          setLoading(pay, true, '支付中…');
          await safe(() => mcd.mockPay(o.orderId), '支付失败');
          setLoading(pay, false, '模拟支付完成');
          await refreshOrders();
        };
        actions.appendChild(pay);
        const link = el('span', 'o-payurl', '支付链接');
        link.onclick = () => toast('演示支付链接：' + o.payUrl, 'success');
        actions.appendChild(link);
      }

      if (canCancel(o.status)) {
        const cancel = el('button', 'btn btn-danger btn-sm', '取消订单');
        cancel.onclick = async () => {
          if (!window.confirm('确定取消该订单吗？（原因：点错了/点多了）')) return;
          const r = await safe(() => mcd.cancelOrder({ orderId: o.orderId, cancelReasonCode: '3' }), '取消失败');
          if (r) { toast('订单已取消', 'success'); await refreshOrders(); }
        };
        actions.appendChild(cancel);
      }

      card.querySelector('.o-foot').appendChild(actions);
      wrap.appendChild(card);
    });
  }

  // 订单页每 5 秒自动刷新状态（让"制作中→待取餐→已完成"可见）
  let ordersTimer = null;
  function startOrderAutoRefresh() {
    clearInterval(ordersTimer);
    ordersTimer = setInterval(() => {
      if (document.querySelector('.tab.active') && document.querySelector('.tab.active').dataset.tab === 'orders') {
        refreshOrders();
      }
    }, 5000);
  }

  /* ====================== Tab 切换 / 弹窗 ====================== */
  function switchTab(name) {
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
    document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === 'tab-' + name));
    if (name === 'orders') { refreshOrders(); startOrderAutoRefresh(); }
    else clearInterval(ordersTimer);
    if (name === 'cart') renderCart();
  }

  function closeModal(id) { $(id).hidden = true; }

  /* ====================== 事件绑定 ====================== */
  function bindEvents() {
    document.querySelectorAll('.tab').forEach((t) => { t.onclick = () => switchTab(t.dataset.tab); });
    $('detailClose').onclick = () => closeModal('detailModal');
    $('checkoutClose').onclick = () => closeModal('checkoutModal');
    $('checkoutBtn').onclick = openCheckout;
    [$('detailModal'), $('checkoutModal')].forEach((m) => {
      m.onclick = (e) => { if (e.target === m) m.hidden = true; };
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { $('detailModal').hidden = true; $('checkoutModal').hidden = true; }
    });
  }

  /* ====================== 启动 ====================== */
  document.addEventListener('DOMContentLoaded', () => {
    bindEvents();
    init();
  });
})();
